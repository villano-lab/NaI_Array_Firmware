SCI_REG_thresh= 0x00000000

