SCI_REG_integral= 0x00000000

