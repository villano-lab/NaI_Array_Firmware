SCI_REG_integral= 0x00000000
SCI_REG_dummyval= 0x00000001

