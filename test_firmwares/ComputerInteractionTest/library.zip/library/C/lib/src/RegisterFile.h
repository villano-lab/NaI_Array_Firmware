#define SCI_REG_integral 0x00000000
#define SCI_REG_runcfg 0x00000001
#define SCI_REG_counter 0x00000002
#define SCI_REG_reset 0x00000003
#define SCI_REG_strobecount 0x00000004
#define SCI_REG_trigcount 0x00000005
#define SCI_REG_peak 0x00000006
