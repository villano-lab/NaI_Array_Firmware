#define SCI_REG_integral 0x00000000
#define SCI_REG_dummyval 0x00000001
