#define SCI_REG_Cutoff 0x00000000
#define SCI_REG_Gate 0x00000001
#define SCI_REG_Integral 0x00000002
#define SCI_REG_Reset 0x00000003
#define SCI_REG_Delay 0x00000004
#define SCI_REG_Counts 0x00000005
