
import Integration2_RegisterFile
from ctypes import *
import array
import numpy as np

import os
mydll = cdll.LoadLibrary(os.path.dirname(__file__) +'/R5560_SDKLib.dll')

def Init():
    return 0

def ConnectDevice(board):
    c_s = c_char_p(board.encode('ascii'))
    da= mydll.R5560_HandleAllocator()
    handle = c_void_p(da)
    err = mydll.R5560_ConnectTCP(c_s, 8888, handle)
    return err, handle

def CloseConnect(handle):
    err = mydll.NI_CloseConnection((handle))
    return err    
    
def ListDevices():
    str_devices=""
    dev_count =-1
    return str_devices, dev_count 

def __abstracted_reg_write(data, address, handle):
    err = mydll.NI_WriteReg(data, address, (handle))
    return err

def __abstracted_reg_read(address, handle):
    data = c_uint(0)
    err = mydll.NI_ReadReg(byref(data), address, (handle))
    return err, data.value

def __abstracted_mem_write(data, count, address, timeout_ms, handle):
    written_data = c_uint(0)
    err = mydll.NI_WriteData(data, count, address, (handle), byref(written_data))
    return err, written_data.value

def __abstracted_mem_read(count, address, timeout_ms, handle):
    data = (c_uint * (2* count))()
    read_data = c_uint(0)
    valid_data = c_uint(0)
    err = mydll.NI_ReadData(byref(data), count, address, (handle), byref(read_data))
    valid_data=read_data
    return err, data, read_data.value, valid_data.value

def __abstracted_fifo_write(data, count, address, address_status, timeout_ms, handle):
    return -1

def __abstracted_fifo_read(count, address, address_status, blocking, timeout_ms, handle):
    data = (c_uint * (2 * count))()
    read_data = c_uint(0)
    valid_data = c_uint(0)
    err = mydll.NI_ReadFifo(byref(data), count, address, address_status, (1 if blocking else 2), timeout_ms, (handle), byref(read_data))
    valid_data=read_data
    return err, data, read_data, valid_data     
    
def __abstracted_DMA_read(dma_channel, handle):
    count = 2*1024*1024;
    data = (c_ulonglong * (count))()
    read_data = c_uint(0)
    err = mydll.NI_DMA_Read(dma_channel, byref(data), count, byref(read_data), (handle))
    vd = (read_data.value / 8);
    return err, data, vd     
    
def __abstracted_DMA_CONFIG(dma_channel, blocking, timeout, buffer_length, handle):
    err = mydll.NI_DMA_SetOptions(dma_channel, blocking, timeout, buffer_length, (handle))
    return err
    
    
def gray_to_bin(num, nbit):
    temp = num ^ (num >> 8)
    temp ^= (temp >> 4)
    temp ^= (temp >> 2)
    temp ^= (temp >> 1)
    return temp    

def REG_Delay_GET(handle):
    [err, data] = __abstracted_reg_read(Integration2_RegisterFile.SCI_REG_Delay, handle)
    return err, data

def REG_Delay_SET(data, handle):
    err = __abstracted_reg_write(data, Integration2_RegisterFile.SCI_REG_Delay, handle)
    return err

def REG_Cutoff_GET(handle):
    [err, data] = __abstracted_reg_read(Integration2_RegisterFile.SCI_REG_Cutoff, handle)
    return err, data

def REG_Cutoff_SET(data, handle):
    err = __abstracted_reg_write(data, Integration2_RegisterFile.SCI_REG_Cutoff, handle)
    return err

def REG_Gate_GET(handle):
    [err, data] = __abstracted_reg_read(Integration2_RegisterFile.SCI_REG_Gate, handle)
    return err, data

def REG_Gate_SET(data, handle):
    err = __abstracted_reg_write(data, Integration2_RegisterFile.SCI_REG_Gate, handle)
    return err

def REG_Reset_GET(handle):
    [err, data] = __abstracted_reg_read(Integration2_RegisterFile.SCI_REG_Reset, handle)
    return err, data

def REG_Reset_SET(data, handle):
    err = __abstracted_reg_write(data, Integration2_RegisterFile.SCI_REG_Reset, handle)
    return err

def REG_Integral_GET(handle):
    [err, data] = __abstracted_reg_read(Integration2_RegisterFile.SCI_REG_Integral, handle)
    return err, data

def REG_Integral_SET(data, handle):
    err = __abstracted_reg_write(data, Integration2_RegisterFile.SCI_REG_Integral, handle)
    return err

def REG_Counts_GET(handle):
    [err, data] = __abstracted_reg_read(Integration2_RegisterFile.SCI_REG_Counts, handle)
    return err, data

def REG_Counts_SET(data, handle):
    err = __abstracted_reg_write(data, Integration2_RegisterFile.SCI_REG_Counts, handle)
    return err

def REG_Read_GET(handle):
    [err, data] = __abstracted_reg_read(Integration2_RegisterFile.SCI_REG_Read, handle)
    return err, data

def REG_Read_SET(data, handle):
    err = __abstracted_reg_write(data, Integration2_RegisterFile.SCI_REG_Read, handle)
    return err

def REG_Empty_GET(handle):
    [err, data] = __abstracted_reg_read(Integration2_RegisterFile.SCI_REG_Empty, handle)
    return err, data

def REG_Empty_SET(data, handle):
    err = __abstracted_reg_write(data, Integration2_RegisterFile.SCI_REG_Empty, handle)
    return err

def REG_Full_GET(handle):
    [err, data] = __abstracted_reg_read(Integration2_RegisterFile.SCI_REG_Full, handle)
    return err, data

def REG_Full_SET(data, handle):
    err = __abstracted_reg_write(data, Integration2_RegisterFile.SCI_REG_Full, handle)
    return err

