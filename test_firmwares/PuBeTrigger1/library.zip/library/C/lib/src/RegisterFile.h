#define SCI_REG_thrs 0x00000000
#define SCI_REG_inhib 0x00000001
#define SCI_REG_polarity 0x00000002
#define SCI_REG_ratereset 0x00020000
#define SCI_REG_RateMeter_0_FIFOADDRESS 0x10000

