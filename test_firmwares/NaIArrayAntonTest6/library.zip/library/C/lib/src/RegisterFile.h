#define SCI_REG_counts 0x00000000
